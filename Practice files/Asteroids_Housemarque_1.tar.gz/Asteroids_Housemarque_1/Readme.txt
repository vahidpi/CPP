// Internship attachment, Housemarque
// Housemarque Pre-Interview Coding Test
// Asteroids using SFML
//
//
// I have watched some videos from youtube
// * https://www.youtube.com/watch?v=UcuuqISJqg0
// * https://www.youtube.com/watch?v=WYSupJ5r2zo&t=117s
// * https://www.youtube.com/watch?v=tux1DQ4Sp3A
// * https://www.youtube.com/watch?v=rWaSo2usU4A
// * https://www.youtube.com/watch?v=axIgxBQVBg0&t=177s
//
//
// I have used Code::Blocks
// This code was compiled by GNU GCC compiler in Linux Ubutu 16.5
// GNU gdb (Ubuntu 7.11.1-0ubuntu1~16.5) 7.11.1
// Have g++ follow the C++11 ISO C++ language standard
//
// It needs bellow files
// * sansation.ttf
// * player2.png
// * stone2.png
// * ufo2.png
// * bullet2.png
// * ufobullet.png
//
//
// Vahid 9.4.2018



